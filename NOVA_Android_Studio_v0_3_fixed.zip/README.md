# NOVA Android v0.2

This is the second native Android milestone.

## Improvements over v0.1
- Native Jetpack Compose app
- Persistent local data using Android DataStore
- Memory survives app restarts
- Tasks survive app restarts
- Task completion state survives app restarts
- Local NOVA question logic
- Cleaner foundation for real AI/backend integration

## Build
Open this folder in Android Studio.
Then:
Build → Build APK(s)

APK:
`app/build/outputs/apk/debug/app-debug.apk`

## Important
This version intentionally does not embed a paid AI API key in the app. Putting a secret AI API key directly inside an APK is unsafe because it can be extracted.

For the production AI version, NOVA should call a secure backend that:
1. authenticates the user,
2. stores encrypted user data,
3. retrieves relevant memory,
4. calls the selected AI model,
5. applies NOVA's permission/action rules,
6. returns the answer/action safely.

## Next milestone: v0.3
- onboarding
- profile
- encrypted backend
- real AI endpoint
- memory retrieval
- document intelligence
- notifications
- permission/approval engine
