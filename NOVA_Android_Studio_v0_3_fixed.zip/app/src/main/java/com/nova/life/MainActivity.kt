package com.nova.life

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

private val Bg = Color(0xFFF5F6F8)
private val Ink = Color(0xFF111827)
private val Muted = Color(0xFF707783)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NovaApp() }
    }
}

@Composable
fun NovaApp() {
    val store = remember { NovaStore(androidx.compose.ui.platform.LocalContext.current) }
    val saved by store.data.collectAsState(initial = NovaData(
        listOf("My daughter's birthday is October 14", "I prefer aisle seats when I fly"),
        listOf("Review car insurance renewal", "Pay school fee", "Check passport expiry"),
        listOf(false, false, false)
    ))
    val scope = rememberCoroutineScope()
    var tab by remember { mutableStateOf(0) }
    var memory by remember { mutableStateOf("") }
    var task by remember { mutableStateOf("") }
    var query by remember { mutableStateOf("") }
    var answer by remember { mutableStateOf("") }

    fun persist(mem: List<String> = saved.memories, tasks: List<String> = saved.tasks, done: List<Boolean> = saved.done) {
        scope.launch { store.save(NovaData(mem, tasks, done)) }
    }

    MaterialTheme(colorScheme = lightColorScheme(primary = Ink, background = Bg)) {
        Scaffold(bottomBar = {
            NavigationBar(containerColor = Color.White) {
                val labels = listOf("Today","Memory","Tasks","Money","Family")
                val icons = listOf(Icons.Default.Home,Icons.Default.Psychology,Icons.Default.CheckCircle,Icons.Default.AccountBalanceWallet,Icons.Default.People)
                labels.forEachIndexed { i,l -> NavigationBarItem(tab==i,{tab=i},{Icon(icons[i],l)},label={Text(l,fontSize=10.sp)}) }
            }
        }) { pad ->
            Column(Modifier.fillMaxSize().background(Bg).padding(pad).padding(18.dp)) {
                Brand()
                Spacer(Modifier.height(18.dp))
                when(tab) {
                    0 -> Today(saved, query, {query=it}, answer, {
                        val q=query.lowercase()
                        answer = when {
                            "birthday" in q -> "Your daughter's birthday is October 14."
                            "forget" in q || "remember" in q -> "You have ${saved.tasks.zip(saved.done).count{!it.second}} open task(s)."
                            "task" in q -> saved.tasks.joinToString("\n") { "• $it" }
                            else -> "This v0.2 demo uses your saved local data. Connect an AI provider in the next backend phase for full natural-language reasoning."
                        }
                    })
                    1 -> Memory(saved.memories,memory,{memory=it}) {
                        if(memory.isNotBlank()) { persist(mem=listOf(memory.trim())+saved.memories); memory="" }
                    }
                    2 -> Tasks(saved.tasks,saved.done,task,{task=it},{
                        if(task.isNotBlank()) { persist(tasks=listOf(task.trim())+saved.tasks,done=listOf(false)+saved.done);task="" }
                    },{i -> val d=saved.done.toMutableList(); while(d.size<saved.tasks.size)d.add(false);d[i]=!d[i];persist(done=d)})
                    3 -> SimplePage("Money","Your budget and spending intelligence will live here.")
                    else -> SimplePage("Family","Family profiles, shared responsibilities and permissions will live here.")
                }
            }
        }
    }
}

@Composable fun Brand(){
    Row(verticalAlignment=Alignment.CenterVertically){
        Box(Modifier.size(42.dp).background(Ink,MaterialTheme.shapes.medium),contentAlignment=Alignment.Center){Text("N",color=Color.White,fontWeight=FontWeight.Bold,fontSize=20.sp)}
        Spacer(Modifier.width(10.dp));Column{Text("NOVA",fontWeight=FontWeight.Bold,letterSpacing=3.sp);Text("Your life, handled.",fontSize=11.sp,color=Muted)}
    }
}
@Composable fun CardBox(content:@Composable ColumnScope.()->Unit){
    Card(Modifier.fillMaxWidth().padding(bottom=12.dp),colors=CardDefaults.cardColors(Color.White)){Column(Modifier.padding(18.dp),content=content)}
}
@Composable fun Title(a:String,b:String){Text(a,fontSize=29.sp,fontWeight=FontWeight.Bold);Spacer(Modifier.height(4.dp));Text(b,color=Muted);Spacer(Modifier.height(18.dp))}
@Composable fun Today(d:NovaData,q:String,setQ:(String)->Unit,ans:String,ask:()->Unit){
    Title("Good morning.","One place for the things that matter.")
    CardBox{Text("LIFE SCORE",fontSize=10.sp,fontWeight=FontWeight.Bold,color=Muted,letterSpacing=2.sp);Text("84/100",fontSize=38.sp,fontWeight=FontWeight.Bold);Text("NOVA is watching your open responsibilities.",color=Muted)}
    CardBox{Text("NEEDS ATTENTION",fontSize=10.sp,fontWeight=FontWeight.Bold,color=Color(0xFFB84343),letterSpacing=2.sp);d.tasks.zip(d.done).filter{!it.second}.take(3).forEach{Text("• ${it.first}",Modifier.padding(vertical=4.dp))}}
    CardBox{Text("ASK NOVA",fontSize=10.sp,fontWeight=FontWeight.Bold,color=Muted,letterSpacing=2.sp);Spacer(Modifier.height(8.dp));OutlinedTextField(q,setQ,Modifier.fillMaxWidth(),placeholder={Text("What am I forgetting?")});Spacer(Modifier.height(8.dp));Button(ask,Modifier.fillMaxWidth()){Text("Ask NOVA")};if(ans.isNotBlank()){Spacer(Modifier.height(10.dp));Text(ans,color=Muted)}}
}
@Composable fun Memory(items:List<String>,input:String,set:(String)->Unit,add:()->Unit){
    Title("Memory","Things NOVA should remember.");Row(verticalAlignment=Alignment.CenterVertically){OutlinedTextField(input,set,Modifier.weight(1f),placeholder={Text("Add a memory")});Spacer(Modifier.width(7.dp));Button(add){Text("Save")}};Spacer(Modifier.height(12.dp));LazyColumn{items(items){CardBox{Text("🧠  $it")}}}
}
@Composable fun Tasks(items:List<String>,done:List<Boolean>,input:String,set:(String)->Unit,add:()->Unit,toggle:(Int)->Unit){
    Title("Tasks","Responsibilities NOVA is tracking.");Row(verticalAlignment=Alignment.CenterVertically){OutlinedTextField(input,set,Modifier.weight(1f),placeholder={Text("Add a task")});Spacer(Modifier.width(7.dp));Button(add){Text("Add")}};Spacer(Modifier.height(12.dp));LazyColumn{items(items.indices.toList()){i->CardBox{Row(verticalAlignment=Alignment.CenterVertically){Checkbox(i<done.size&&done[i],{toggle(i)});Text(items[i])}}}}
}
@Composable fun SimplePage(title:String,subtitle:String){Title(title,subtitle);CardBox{Text("Coming next",fontWeight=FontWeight.Bold);Spacer(Modifier.height(6.dp));Text("The architecture is ready for this module. We will connect real data, permissions and AI in the next phase.",color=Muted)}}
