package com.nova.life

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.map

private val Context.novaDataStore by preferencesDataStore("nova_data")

data class NovaData(
    val memories: List<String>,
    val tasks: List<String>,
    val done: List<Boolean>
)

class NovaStore(private val context: Context) {
    private val memoriesKey = stringPreferencesKey("memories")
    private val tasksKey = stringPreferencesKey("tasks")
    private val doneKey = stringPreferencesKey("done")

    val data = context.novaDataStore.data.map { p ->
        val memories = p[memoriesKey].orEmpty().split("|").filter { it.isNotBlank() }
        val tasks = p[tasksKey].orEmpty().split("|").filter { it.isNotBlank() }
        val done = p[doneKey].orEmpty().split(",").map { it == "1" }
        NovaData(memories, tasks, done)
    }

    suspend fun save(data: NovaData) {
        context.novaDataStore.edit { p ->
            p[memoriesKey] = data.memories.joinToString("|")
            p[tasksKey] = data.tasks.joinToString("|")
            p[doneKey] = data.done.joinToString(",") { if (it) "1" else "0" }
        }
    }
}
